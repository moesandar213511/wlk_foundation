<?php $__env->startSection('title','Power Phoenix'); ?>
<?php $__env->startSection('content'); ?>
<!-- banner -->
<div class="banner_w3lspvt">
    <div class="csslider infinity" id="slider1">
        <input type="radio" name="slides" checked="checked" id="slides_1"/>
        <input type="radio" name="slides" id="slides_2"/>
        <input type="radio" name="slides" id="slides_3"/>
        <input type="radio" name="slides" id="slides_4"/>

        <div class="navigation"> 
            <div>
              <label for="slides_1"></label>
              <label for="slides_2"></label>
              <label for="slides_3"></label>
              <label for="slides_4"></label>
            </div>
        </div>
    </div>
</div>
<!-- //banner -->
<ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item active">About</li>
</ol>

<!-- section -->
<section class="section py-5">
    <div class="container py-md-5">
        <div class="row section_grids">
            <div class="col-lg-6">
                <h3>Welcome To Our Website</h3>
                <p class="my-4">Nulla felis tortor, rutrum eget feugiat non, blandit nec tellus. Nam pharetra ipsum ligula volutpat, a finibus. Vivamus eget est
                init odio tempor interdum. Mauris maximus fermentum arcu, ac finibus ante. Sed mattis risus at ipsum elementum,ut auctor turpis cursus.
                Sed sed odio pharetra, aliquet velit cursus, vehicula enim.</p>
                <p>Nam pharetra ipsum,  ligula volutpat a finibus.Vivamus eget est ac finibus ante. Sed mattis risus eget laoreet ligula</p>
            </div>
            <div class="col-lg-6 mt-lg-0 mt-5 img">
                <img src="images/banner3.jpg" class="img-fluid" alt=""/>
            </div>
        </div>
     <div class="row service-grid-grids text-center pt-lg-5 mt-3">
            <div class="col-lg-4 col-md-6 service-grid service-grid1">
                <div class="service-icon">
                    <span class="fa fa-pencil-square-o" aria-hidden="true"></span>
                </div>
                <h4 class="mt-3">Best Solutions</h4>
                <p class="mt-3">Perspiciatis unde omnis iste natus doloret ipsum volupte ut accusal ntium dolor remque laudantium, totam dolor.</p>
            </div>
            <div class="col-lg-4 col-md-6 service-grid service-grid2 mt-md-0 mt-5">
                <div class="service-icon">
                    <span class="fa fa-bullseye " aria-hidden="true"></span>
                </div>
                <h4 class="mt-3">Creative Work</h4>
                <p class="mt-3">Perspiciatis unde omnis iste natus doloret ipsum volupte ut accusal ntium dolor remque laudantium, totam dolor.</p>
            </div>
            <div class="col-lg-4 col-md-6 service-grid service-grid3 mt-lg-0 mt-5">
                <div class="service-icon">
                    <span class="fa fa-database" aria-hidden="true"></span>
                </div>
                <h4 class="mt-3">Great Designs</h4>
                <p class="mt-3">Perspiciatis unde omnis iste natus doloret ipsum volupte ut accusal ntium dolor remque laudantium, totam dolor.</p>
            </div>
    </div>
</section>
<!-- //section -->
    <!-- facts -->
<section class="facts" id="facts">
    <div class="container">
        <div class="row">
        <div class="col-lg-4 p-lg-0 text-center">
                <img src="images/2.png" class="img-fluid" alt="">
            </div>
            <div class="col-lg-8 pt-5">
                <div class="row inner-heading">
                    <h3 class="tittle text-capitalize text-left my-md-4"> Why Choose Us</h3>
                    <p class="mt-md-0 mt-2">We carefully listen to your desire and objective. By fully focusing on your business model, we provide suitable, reasonable and effective suggestions. 

                    Timing is everything.
                    
                    Trustable Technicians is our team are experienced,skillful,and studied Engineering and Information Technology for Six years in Russian,one of the World leading Technological Country.</p>
                </div>
                <div class="row mt-5 fact-grid-main">
                    <div class="col-sm-4 stats-grid">
                        <span class="fa fa-tasks"></span>
                        <span>250</span>
                        <h4>Completed Work</h4>
                    </div>
                    <div class="col-sm-4 stats-grid">
                        <span class="fa fa-copy"></span>
                        <span>50+</span>
                        <h4>Projects</h4>
                    </div>
                    <div class="col-sm-4 stats-grid">
                        <span class="fa fa-smile-o"></span>
                        <span>2000+</span>
                        <h4>Satisfied clients</h4>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>
<!-- //facts -->

<!-- team -->
<section class="team-wthree py-5" id="team">
    <div class="container py-lg-3">
        <h3 class="heading text-capitalize mb-4">our team</h3>
        <div class="team-members">
            <div class="row">
                <!-- <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-4 col-md-6 mt-lg-0 mt-4">
                    <div class="box5">
                        <img src="<?php echo e(asset('upload/team/'.$member['photo'])); ?>" alt="" class=" img-fluid" />
                        <ul class="icon">
                            <li><a href="#" class="fa fa-facebook"></a></li>
                            <li><a href="#" class="fa fa-link"></a></li>
                        </ul>
                        <div class="box-content">
                            <h3 class="title"><?php echo e($member['name']); ?>}</h3>
                            <span class="post"><?php echo e($member['position']); ?>}</span>
                        </div>
                    </div>
                    <p class="text">Programmer @ ROS Myanmar Community</p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                <div class="col-lg-3 col-md-6 mt-md-0 mt-4">
                    <div class="box5">
                        <img src="images/Team/Picture3.jpg" alt="" class=" img-fluid" />
                        <ul class="icon">
                            <li><a href="#" class="fa fa-facebook"></a></li>
                            <li><a href="#" class="fa fa-link"></a></li>
                        </ul>
                        <div class="box-content">
                            <h3 class="title">Mr Pyae Soan Aung</h3>
                            <span class="post">Team Leader @ ROS</span>
                        </div>
                    </div>
                    <p class="text">Programmer @ ROS Myanmar Community</p>
                </div>
                <div class="col-lg-3 col-md-6 mt-md-0 mt-4">
                    <div class="box5">
                        <img src="images/Team/Picture1.jpg" alt="" class=" img-fluid" />
                        <ul class="icon">
                            <li><a href="#" class="fa fa-facebook"></a></li>
                            <li><a href="#" class="fa fa-link"></a></li>
                        </ul>
                        <div class="box-content">
                            <h3 class="title">Dr. Aung Win Htut
</h3>
                            <span class="post">MD</span>
                        </div>
                    </div>
                    <p class="text">Engineer @ Moscow Power Engineering Institute
</p>
                </div>
                <div class="col-lg-3 col-md-6 mt-md-0 mt-4">
                    <div class="box5">
                        <img src="images/Team/Picture2.jpg" alt="" class=" img-fluid" />
                        <ul class="icon">
                            <li><a href="#" class="fa fa-facebook"></a></li>
                            <li><a href="#" class="fa fa-link"></a></li>
                        </ul>
                        <div class="box-content">
                            <h3 class="title">Mr.Yar Zar Min</h3>
                            <span class="post">Team Leader @ PLC</span>
                        </div>
                    </div>
                    <p class="text">Programmer at PLC Programmable Logic Controller Plc Logic controllers
</p>
                </div>
                <div class="col-lg-3 col-md-6 mt-md-0 mt-4">
                    <div class="box5">
                        <img src="images/Team/Picture5.jpg" alt="" class=" img-fluid" />
                        <ul class="icon">
                            <li><a href="#" class="fa fa-facebook"></a></li>
                            <li><a href="#" class="fa fa-link"></a></li>
                        </ul>
                        <div class="box-content">
                            <h3 class="title">Mr.Thu Yein Soe</h3>
                            <span class="post">Team Leader @ IT</span>
                        </div>
                    </div>
                    <p class="text">Web Designer and Web Developer @ Green Hackers
</p>
                </div>
            </div>
        </div>
</section>
<!-- //team -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\power_phoenixajax\resources\views/user/about.blade.php ENDPATH**/ ?>