<?php $__env->startSection('title','WLK Foundation'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
  <div class="row justify-content-center" style="background-color: #FFEAF2;"><br><br>
    <div class="col-md-10 col-sm-12 col-xs-10 col-md-offset-1 col-xs-offset-1" style=" height: auto;">
      <div class="col-md-6 col-sm-12 col-xs-12 " style="height: 510px;">
        <center>
          <div  style=" background-color: #fff;height: 487px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2;width: 95%;">
            <h1 style="font-weight: 600;font-size: 21px; ">Cyclone Idai</h1>
            <p style="font-size: 16px; color: red;">
              The cyclone is the strongest to hit Southern Africa. At least 1.5 million people in Malawi, Mozambique and Zimbabwe have been affected.
            </p><br>
            <img src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;margin-top: -10px;">
            <br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;">LEARN MORE</button><br><br>
          </div><br>
        </center>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12" >
        <center>
          <div  style=" background-color: #fff;height: auto; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2; width: 95%;">
            <h1 style="font-weight: 700;font-size: 21px; ">Conflict In Yemen</h1>
            <p style="font-size: 16px;color: red;"> Ongoing violence in Yemen has resulted in 80% of the population in need of humanitarian assistance. Over 21 million people struggle to access food, water and medical care.</p>

            <img src="img/wailukyawc3.jpg" width="100%" height="auto" style="position: relative;bottom: -10px;"><br><br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;margin-top: -10px;">LEARN MORE</button><br><br>
          </div>
        </center>
      </div>
    </div>
  </div>

      <div class="row justify-content-center" style="background-color: #FFEAF2;"><br><br>
    <div class="col-md-10 col-sm-12 col-xs-10 col-md-offset-1 col-xs-offset-1" style=" height: auto;">
      <div class="col-md-6 col-sm-12 col-xs-12 " style="height: 510px;">
        <center>
          <div  style=" background-color: #fff;height: 505px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2;width: 95%;">
            <h1 style="font-weight: 600;font-size: 21px; ">DRC: Ebola Crisis Kills Hundreds </h1>
            <p style="font-size: 16px; color: red;">
              Ebola is a rare, and usually fatal, hemorrhagic fever. As of December 2018, the fatality rate of Ebola in the DRC is as high as 56%. 
            </p><br><br><br>
            <img src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;margin-top: -10px;">
            <br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;">LEARN MORE</button><br><br>
          </div><br>
        </center>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12" >
        <center>
          <div  style=" background-color: #fff;height: auto; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2; width: 95%;">
            <h1 style="font-weight: 700;font-size: 21px; ">Millions Flee Venezuela</h1>
            <p style="font-size: 16px;color: red;"> More than  3 million people—about ten percent of the population—have fled Venezuela  as a result of political instability, hunger, inflation, poverty and soaring crime rates. It has been described as the largest exodus in Latin America in a hundred years. </p>

            <img src="img/wailukyawc3.jpg" width="100%" height="auto" style="position: relative;bottom: -10px;"><br><br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;margin-top: -10px;">LEARN MORE</button><br><br>
          </div>
        </center>
      </div>
    </div>
  </div>


      <div class="row justify-content-center" style="background-color: #FFEAF2;"><br><br>
    <div class="col-md-10 col-sm-12 col-xs-10 col-md-offset-1 col-xs-offset-1" style=" height: auto;">
      <div class="col-md-6 col-sm-12 col-xs-12 " style="height: 510px;">
        <center>
          <div  style=" background-color: #fff;height: 525px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2;width: 95%;">
            <h1 style="font-weight: 600;font-size: 21px; ">Syrian Refugee Crisis</h1>
            <p style="font-size: 16px; color: red;">
              The ongoing armed conflict in Syria has left more than half the population, up to 13.5 million people, more than half of whom are children, in need of humanitarian aid. We’re on the ground inside Syria and in neighboring countries helping Syrians as they struggle to survive.
            </p><br>
            <img src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;margin-top: -10px;">
            <br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;">LEARN MORE</button><br><br>
          </div><br>
        </center>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12" >
        <center>
          <div  style=" background-color: #fff;height: 525px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2; width: 95%;">
            <h1 style="font-weight: 700;font-size: 21px; ">Refugees flee Myanmar for Bangladesh</h1>
            <p style="font-size: 16px;color: red;"> More than 906,000 people have fled to Bangladesh after an escalation of violence in Myanmar's northern Rakhine State. Around 80 percent of the refugees are women and children.</p><br><br>

            <img src="img/wailukyawc3.jpg" width="100%" height="auto" style="position: relative;bottom: -10px;"><br><br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;margin-top: -10px;">LEARN MORE</button><br><br>
          </div>
        </center>
      </div>
    </div>
  </div>

      <div class="row justify-content-center" style="background-color: #FFEAF2;"><br><br>
    <div class="col-md-10 col-sm-12 col-xs-10 col-md-offset-1 col-xs-offset-1" style=" height: auto;">
      <div class="col-md-6 col-sm-12 col-xs-12 " style="height: 510px;">
        <center>
          <div  style=" background-color: #fff;height: 505px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2;width: 95%;">
            <h1 style="font-weight: 600;font-size: 21px; ">Nigeria faces disease outbreaks and hunger</h1>
            <p style="font-size: 16px; color: red;">
              The violent conflict that began in Nigeria in 2009 has resulted in a severe crisis in the northeast of the country, creating vast need for lifesaving support.
            </p><br><br>
            <img src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;margin-top: -10px;">
            <br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;">LEARN MORE</button><br><br>
          </div><br>
        </center>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12" >
        <center>
          <div  style=" background-color: #fff;height: 505px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2; width: 95%;">
            <h1 style="font-weight: 700;font-size: 21px; ">South Sudan Violence</h1>
            <p style="font-size: 16px;color: red;"> A recent escalation in violence underlines the fragile situation in the world’s youngest nation, still recovering from almost 50 years of civil war. Almost 5 million people in South Sudan need immediate assistance and 3.7 million are at risk for hunger.</p>

            <img src="img/wailukyawc3.jpg" width="100%" height="auto" style="position: relative;bottom: -10px;"><br><br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;margin-top: -10px;">LEARN MORE</button><br><br>
          </div>
        </center>
      </div>
    </div>
  </div>

      

  <div class="row justify-content-center" style="background-color: #FFEAF2;"><br><br>
    <div class="col-md-10 col-sm-12 col-xs-10 col-md-offset-1 col-xs-offset-1" style=" height: auto;">
      <div class="col-md-6 col-sm-12 col-xs-12 " style="height: 510px;">
        <center>
          <div  style=" background-color: #fff;height: 485px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2;width: 95%;">
            <h1 style="font-weight: 600;font-size: 21px; ">Haiti Earthquake Recovery</h1>
            <p style="font-size: 16px; color: red;">
              The 2010 earthquake in Haiti killed 220,000 people and left 2.3 million homeless. Five years later, we remain as committed as ever to helping Haitians rebuild their lives and communities.
            </p><br>
            <img src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;margin-top: -10px;">
            <br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;">LEARN MORE</button><br><br>
          </div><br>
        </center>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12" >
        <center>
          <div  style=" background-color: #fff;height: 485px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2; width: 95%;">
            <h1 style="font-weight: 700;font-size: 21px; ">Deadly Earthquake Strikes Nepal</h1>
            <p style="font-size: 16px;color: red;"> The worst earthquake to hit Nepal in more than 80 years has killed more than 7,000 people and injured more than 14,000.</p><br>

            <img src="img/wailukyawc3.jpg" width="100%" height="auto" style="position: relative;bottom: -10px;"><br><br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;margin-top: -10px;">LEARN MORE</button><br><br>
          </div>
        </center>
      </div>
    </div>
  </div>
</div>
</div>

</div>
<!-- ======================================================================= -->
      <br><br>
<div class="container">
    <div class="row justify-content-around" >
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="col-md-5"><br>
                <img  src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;">

            </div>
            <div class="col-md-7" style="height: auto;">
                <h1>Why WLK?</h1>
                <p style="font-size: 16px;">A career at CARE is truly a one-of-a-kind experience.It's more than working for a global leader,it and opportunity to be a part of some thing that can help bring about lasting change in the world.We'll looking for experienced professional who not only align with our values but also want to make a different,developed and inspire others,drive innovative ideas and deliver results.</p><br>
                <p style="font-size: 16px;">A career at CARE is truly a one-of-a-kind experience.It's more than working for a global leader,it and opportunity to be a part of some thing that can help bring about lasting change in the world.We'll looking for experienced professional who not only align with our values but also want to make a different,developed and inspire others,drive innovative ideas and deliver results.</p><br>

                <center>
                    <h4 style="font-weight: 900;">WANT MORE INFO ON CARE? CHECK OUT THESE LINKS:</h4>
                <p>
                    <a href="" class="a">Benefit</a> |
                    <a href="" class="a">Diversity</a> |
                    <a href="" class="a">Core Values</a><br>
                    <a href="" class="a">Carrer FAQs</a> |
                    <a href="" class="a">Mission and Vision</a>
                </p><br>
                </center>
                <div class="row justify-content-end">
                  <div class="col-md-5">
                    <button class="btn" id="parallelogram" style="font-weight: 700; color: #fff; background-color: #6288CA; height: 40px; width: auto;">SEARCH FOR OPPORTUNITIES</button>
                  </div>
                  <div class="col-md-5">
                    <button class="btn" id="parallelogram" style="font-weight: 700; color: #fff; background-color: #6288CA; height: 40px;width: auto;">SEARCH FOR AN ONTERNSHIO/FELLOWSHIP</button>
                  </div>               
                
                </div>
                
            </div>
        </div>
    </div><br><br>
</div>

<!-- ---------------------------------------------------------- -->

<!-- ============================================================================ -->
<div class="container-fluid">
  <div class="row justify-content-around" style="background-color: #E5DBEA;height: 450px;">
    <div class="col-md-12 col-xs-12 col-sm-12">
      <div class="col-md-5 col-xs-12 col-sm-12 col-md-offset-1" style="padding-top: 10px;"><br>
        <h1>WHERE WE WORK</h1><br>
        <p style="font-size: 16px;">Last year,CARE worked in 93 countries,reaching 63 million people through 950 poverty-fighting development and humanitarian aid programs.</p>
        <p>
          Explore our work in:
        </p>
        <ul>
          <li>Yangon</li>
          <li>Mandalay</li>
          <li>Bago</li>
          <li>TaungGyi</li>
        </ul>
        <br><br><br>
        <center>
          <button class="btn" id="parallelogram" style="font-weight: 500; color: #fff; background-color: #6288CA; width: 170px; height: 40px; position: relative; top:-20px;">VIEW FULL MAP
          </button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <button class="btn" id="parallelogram" style="font-weight: 500; color: #fff; background-color: #6288CA; width: 170px; height: 40px; position: relative; top:-20px;">VIEW CRISIS MAP
          </button>
        </center>
      </div>

      <div class="col-md-5 col-xs-12 col-sm-12" style="height: 450px;padding-top: 30px;"><br>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3818.633365603478!2d96.21300891434622!3d16.844535022668605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c19373aae8dda7%3A0x66b1fddc29486ea!2sGreen+Hackers+Institute!5e0!3m2!1smy!2smm!4v1561137016652!5m2!1smy!2smm" width="106%" height="85%" frameborder="0" style="border:0; position: relative;left: -14px;" allowfullscreen></iframe>

        <br>
       
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>







 
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/emergencyclick.blade.php ENDPATH**/ ?>