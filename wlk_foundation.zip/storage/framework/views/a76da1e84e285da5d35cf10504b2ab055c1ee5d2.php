<div class="sidebar" data-color="purple" data-background-color="white" data-image="<?php echo e(asset('images/admin_image//sidebar-1.jpg')); ?>">
    <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
    <div class="logo">
        <a href="http://renomyanmar.chitminthu.ml" class="simple-text logo-normal">
            RenoMyanmar
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item <?php if($url=="dashboard"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="nav-item <?php if($url=="blog"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/blog')); ?>">
                    <i class="material-icons">person</i>
                    <p>Manage Blog</p>
                </a>
            </li>
             <li class="nav-item <?php if($url=="service"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/service')); ?>">
                    <i class="material-icons">content_paste</i>
                    <p>Service</p>
                </a>
            </li>
            <li class="nav-item <?php if($url=="team"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/team')); ?>">
                    <i class="material-icons">person</i>
                    <p>Team</p>
                </a>
            </li>
            <li class="nav-item <?php if($url=="office"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/office')); ?>">
                    <i class="material-icons">library_books</i>
                    <p>Office Infomation</p>
                </a>
            </li>
            <li class="nav-item <?php if($url=="client"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/client')); ?>">
                    <i class="material-icons">person</i>
                    <p>Manage Client</p>
                </a>
            </li>
            <li class="nav-item <?php if($url=="contact"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/contact')); ?>">
                    <i class="material-icons">content_paste</i>
                    <p>Contact</p>
                </a>
            </li>


            <!-- <li class="nav-item <?php if($url=="company_profile"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/company_profile')); ?>">
                    <i class="material-icons">person</i>
                    <p>Manage Website</p>
                </a>
            </li>
            <li class="nav-item <?php if($url=="company_list"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/company_list')); ?>">
                    <i class="material-icons">content_paste</i>
                    <p>Company List</p>
                </a>
            </li>
            <li class="nav-item <?php if($url=="category"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/category')); ?>">
                    <i class="material-icons">library_books</i>
                    <p>Manage Category</p>
                </a>
            </li> -->
            <!-- <li class="nav-item <?php if($url=="blog"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/blog')); ?>">
                    <i class="material-icons">bubble_chart</i>
                    <p>Manage Blog</p>
                </a>
            </li> -->
            <!-- <li class="nav-item <?php if($url=="feedback"): ?> active <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(url('admin/feedback')); ?>">
                    <i class="material-icons">location_ons</i>
                    <p>Manage Feedback</p>
                </a>
            </li> -->
            
                
                    
                    
                
            
            
                
                    
                    
                
            
            
                
                    
                    
                
            
        </ul>
    </div>
</div><?php /**PATH D:\xampp\htdocs\power_phoenixajax\resources\views/layouts/site_admin/site_admin_sidebar.blade.php ENDPATH**/ ?>