<?php $__env->startSection('title','WLK Foundation'); ?>
<?php $__env->startSection('content'); ?>
    
        
        <section class="section normalhead lb" style="background: linear-gradient(45deg, #3ac5c8 1%, #0b509e 100%);">
			<div class="container">
				<div class="row">	
					<div class="col-md-10 col-md-offset-1 col-sm-12 text-center">
						<h2>Blog & News</h2>
						<p class="lead">We publish latest news, activities about foundation for our client.</p>
					</div><!-- end col -->
				</div><!-- end row -->
			</div><!-- end container -->
		</section><!-- end section -->

		<section class="section">
			<div class="container">
				<div class="row">
                    
                    
					<div class="content col-md-12 blog-alt">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="blog-box clearfix">
                                    <div class="media-box">
                                        <img src="<?php echo e($blog_obj['photo']); ?>" alt="" class="img-responsive img-thumbnail" style="width:150%;height:30%;">
                                    </div><!-- end media-box -->
                                    
                                </div><!-- end blogbox -->
                            </div>
                            <div class="col-md-11 col-md-offset-1">
                                <div class="blog-single">
                                        <div class="blog-meta">
                                            <ul class="list-inline">
                                                <li><a href="#"><i class="fa fa-calendar-o"></i><?php echo e($blog_obj['created_at']->format('M d-Y')); ?></a></li>
                                                
                                            </ul>
                                        </div><!-- end meta -->
                                        <h3 class="post-title"><div class="myanmar"><?php echo e($blog_obj['title']); ?></div></h3>
                                    <div class="myanmar"><?php echo $blog_obj['detail']; ?></div>
                                </div><!-- end blog-desc -->
                            </div>
                        </div>
						

                        
					</div><!-- end content -->
				</div><!-- end row -->
			</div><!-- end container -->
		</section><!-- end section -->

		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/blogSingle.blade.php ENDPATH**/ ?>