<header>
	<div class="container">
		<div class="header d-lg-flex justify-content-between align-items-center">
			<div class="header-agile">
				<h1>
					<a class="navbar-brand logo" href="index.html">
					Power Phoenix
					</a>
				</h1>
			</div>
			<div class="nav_w3ls">
				<nav>
					<label for="drop" class="toggle mt-lg-0 mt-2"><span class="fa fa-bars" aria-hidden="true"></span></label>
					<input type="checkbox" id="drop" />
						<ul class="menu">
							<li class="mr-lg-3 mr-2 active"><a href="<?php echo e(url('/index')); ?>">Home</a></li>
							<li class="mr-lg-3 mr-2"><a href="<?php echo e(url('/about')); ?>">About</a></li>
							<li class="mr-lg-3 mr-2"><a href="<?php echo e(url('/service')); ?>">Services</a></li>
							<li class="mr-lg-3 mr-2"><a href="<?php echo e(url('/blog')); ?>">Blog</a></li>
							<li class="mr-lg-3 mr-2"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
						</ul>
				</nav>
			</div>
			<div class="buttons mt-lg-0 mt-2">
				<a href="https://www.facebook.com/powerphoenixmyanmar/" target="_blank"><span class="fa mr-1 fa-facebook"></span></a>
				<a href="#"><span class="fa mr-1 fa-twitter"></span></a>
				<a href="#"><span class="fa mr-1 fa-linkedin"></span></a>
			</div>

		</div>
	</div>
</header><?php /**PATH D:\xampp\htdocs\power_phoenix\resources\views/user/site_user/header_user.blade.php ENDPATH**/ ?>