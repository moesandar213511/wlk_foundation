<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Admin|Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav_bar_text'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-body">
                          <div class="table-responsive">
                                  <table class="table table-hovered">
                                    <tbody>
                                      <tr>
                                          <td><b>Photo</b></td>
                                          <td>
                                              <img src="<?php echo e($blog_detail['photo']); ?>" width="200px;" alt="">
                                          </td>
                                      </tr>
                                      <tr>
                                        <td><b>Title</b></td>
                                        <td><?php echo e($blog_detail['title']); ?></td>
                                      </tr>
                                      <tr>
                                        <td><b>Date</b></td>
                                        <td><?php echo e($blog_detail['created_at']->format('M d-Y')); ?></td>
                                      </tr>
                                      <tr>
                                        <td><b>Description</b></td>
                                        <td><?php echo $blog_detail['detail']; ?></td>
                                      </tr>

                                    </tbody>
                                  </table>
                                </div>
                          </div>
                        </div>
                  </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_admin.site_admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/site_admin/blog_detail.blade.php ENDPATH**/ ?>