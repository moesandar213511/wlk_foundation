<?php $__env->startSection('title','Power Phoenix'); ?>
<?php $__env->startSection('content'); ?>
<!-- banner -->
<div class="banner_w3lspvt" id="home">
	<div class="csslider infinity" id="slider1">
		<input type="radio" name="slides" checked="checked" id="slides_1"/>
		<input type="radio" name="slides" id="slides_2"/>
		<input type="radio" name="slides" id="slides_3"/>
		<input type="radio" name="slides" id="slides_4"/>


		<div class="navigation"> 
			<div>
			  <label for="slides_1"></label>
			  <label for="slides_2"></label>
			  <label for="slides_3"></label>
			  <label for="slides_4"></label>
			</div>
		</div>
	</div>
</div>
<!-- //banner -->
<ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item active">Services</li>
</ol>
<section class="ab-info-main py-md-5 py-4">
        <div class="container py-md-5 py-4">
            <h3 class="tittle text-center mb-lg-5 mb-3">Our Services</h3>
             <div class="row">
                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div style="-webkit-box-shadow: 0px 0px 5px #000;-moz-box-shadow: 0px 0px 5px #000;box-shadow: 0px 0px 5px #000;margin-bottom:20px;height:300px;">
                        <img src="<?php echo e(asset('upload/service/'.$ser->photo)); ?>" style="width: 100%;height: 200px;" alt="" class="img-responsive">
                        <a href="<?php echo e(url('/serviceDetail/'.$ser->id)); ?>">
                            <h4 class="text-center" style="padding: 10px; color: #ff9800; font-size: 19px;">
                                <?php echo e($ser->title); ?>

                            </h4>
                        </a>
                    </div>                 
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\power_phoenixajax\resources\views/user/service.blade.php ENDPATH**/ ?>