<div class="container-fluid">
  <div class="row justify-content-center">
    <div class="col-md-12 col-sm-12 col-xs-12">
    <br><br><br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="<?php echo e(url('img/wailukyawc1.jpg')); ?>" alt="Los Angeles" style="width:100%; height: 700px;">
      </div>

      <div class="item">
        <img src="<?php echo e(url('img/wailukyawc2.jpg')); ?>" alt="Chicago" style="width:100%; height: 700px;">
      </div>
    
      <div class="item">
        <img src="<?php echo e(url('img/wlkow.jpg')); ?>" alt="New york" style="width:100%; height: 700px;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" style=" margin-left: -80px;"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" style=" margin-right: -80px;"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
</div>
</div><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/site_user/slideshow.blade.php ENDPATH**/ ?>