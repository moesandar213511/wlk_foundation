<?php $__env->startSection('title','WLK Foundation'); ?>
<?php echo $__env->make("user.site_user.slideshow", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
  <div class="row justify-content-center" style="background-color: #FFEAF2;"><br><br>
    <div class="col-md-10 col-sm-12 col-xs-10 col-md-offset-1 col-xs-offset-1" style=" height: auto;">
      <div class="col-md-6 col-sm-12 col-xs-12 " style="height: 510px;">
        <center>
          <div  style=" background-color: #fff;height: 510px; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2;width: 95%;">
            <h1 style="font-weight: 600;font-size: 21px; ">Partnering with USAID to Deliver Lasting Change</h1>
            <p style="font-size: 16px; color: red;">
              CARE has partnered with USAID for more than 6 decades. Together, CARE and USAID are working to find innovative and sustainable solutions to challenging development problems.            </p><br>
            <img src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;margin-top: -10px;">
            <br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;">LEARN MORE</button>
          </div>
        </center>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12" >
        <center>
          <div  style=" background-color: #fff;height: 100%; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2; width: 95%;">
            <h1 style="font-weight: 700;font-size: 21px; ">CARE USA 2017 Annual Report</h1>
            <p style="font-size: 16px;color: red;"> Check out our latest annual report and see how, with your help, we’re saving lives, defeating poverty and achieving social justice worldwide.</p>

            <img src="img/wailukyawc3.jpg" width="100%" height="auto" style="position: relative;bottom: -10px;"><br><br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;margin-top: -10px;">LEARN MORE</button><br><br><br>
          </div>
        </center>
      </div>
    </div>
  </div>
</div>
<!-- ======================================================================= -->
<!-- ======================================================================= -->
<div class="container-fluid" style="background-color: lightblue;">
    <div class="row justify-content-around"><br><br>
      <div class="col-md-11 col-lg-11 col-sm-11 col-xs-10">
        <div class="row justify-content-around">
        <center> 
          <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
            <div  style=" background-color: #5868CE; width: 90%; height: auto;margin-left: 70px;  border-top: 20px solid #960C13;border-bottom: 30px solid lightblue;border-radius: 10px 0px 0px 10px;">
                <h4 style="font-weight: 800; color: #fff;">CARE THROUGH THE YEARS</h4>
                <p style="font-size: 14px; color: #fff;">Women and girls are hit hardest by poverty. </p>
                <a href="https://www.care.org/work/womens-empowerment" style="text-decoration: none;color:#960C13;font-size: 18px;font-weight: 600;">Learn more</a>
                <img src="img/poor7.jpg" alt="" style="width: 100%;">
            </div>
          </div>

          <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
            <div style=" background-color: #5868CE; width: 90%;  height:  auto;margin-left: 70px;  border-top: 20px solid #960C13;border-bottom: 30px solid lightblue;border-radius: 10px 0px 0px 10px;">
                <h4 style="font-weight: 800; color: #fff;">INNOVACTION <br> AT WORK</h4>
                <p style="font-size: 14px; color: #fff;">Community-centric health programs are critical to lifting people from poverty.</p>
                <a href="https://www.care.org/work/health" style="text-decoration: none;color:#960C13;font-size: 18px;font-weight: 600;">Learn more</a>
                <img src="img/poor7.jpg" alt="" style="width: 100%;">
            </div>
          </div>

          <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
            <div style=" background-color: #5868CE; width: 90%; height:  auto;margin-left: 70px; border-top: 20px solid #960C13;border-bottom: 30px solid lightblue;border-radius: 10px 0px 0px 10px;">
              
                <h4 style="font-weight: 800;color: #fff;">JOIN <br> THE VILLAGE</h4>
                <p style="font-size: 14px;color: #fff;">When disaster strikes, hunger and malnutrition are not far behind.</p>
                <a href="https://www.care.org/work/world-hunger" style="text-decoration: none;color:#960C13;font-size: 18px;font-weight: 600;">Learn more</a>
                <img src="img/poor7.jpg" alt="" style="width: 100%;">
              
              </div>
          </div>
          <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
            <div style=" background-color: #5868CE; width: 90%; height: auto;margin-left: 70px;  border-top: 20px solid #960C13;border-bottom: 30px solid lightblue;border-radius: 10px 0px 0px 10px;">
                <h4 style="font-weight: 800; color: #fff;">OUR <br> STORES</h4>
                <p style="font-size: 14px; color: #fff;">Equipped with knowledge,confidence, kids grow up to lead healthier lives.</p>
                <a href="https://www.care.org/work/education" style="text-decoration: none; color:#960C13;font-size: 18px;font-weight: 600;">Learn more</a>
                <img src="img/poor7.jpg" alt="" style="width: 100%;">
            </div>
            </center> 
          </div>
        </div>
      </div>
    </div><br><br>
  </div>
  <!-- -------------------------------------=====-------------------------------- -->
  <div class="container-fluid">
  <div class="row justify-content-center" style="background-color: #FFEAF2;"><br><br>
    <div class="col-md-10 col-sm-12 col-xs-10 col-md-offset-1 col-xs-offset-1" style=" height: auto;">
      <div class="col-md-6 col-sm-12 col-xs-12 " style="height: auto;">
        <center>
          <div  style=" background-color: #fff;height: auto; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2;width: 95%;">
            <h1 style="font-weight: 600;font-size: 21px; ">IN THE NEWS</h1><br>

            <img src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;margin-top: -10px;">
            <p style="font-size: 16px; color: ;"><br>
              Marca Perú, the government of Peru’s main tourism and export brand, shared a video interview of CARE Ambassador Rita Angel Taylor (RAT), who discussed her trip with CARE to...</p>
            
            <br><br>
            <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;">SEE MORE</button><br><br><br>
          </div>
        </center>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12" >
        <center>
          <div  style=" background-color: #fff;height: 100%; border-top: 10px solid #DD461C; border-bottom: 30px solid #FFEAF2; width: 95%;">
            <h1 style="font-weight: 700;font-size: 21px; ">WANTED: YOUR VOICE</h1>
              <p style="font-size: 16px;">Join the CARE Action Network to find out how you can get involved in your own community while making a difference in the lives of people around the world.</p><br><br>

              <button id="parallelogram" class="btn pull-right" style=" background-color: #DD461C; color: white;top: -20px;text-align: center;">GET INVOLVED</button>
              <a href="Donate.html"><button id="parallelogram" class="btn pull-right" style=" background-color: orange; color: white;top: -20px;margin-right: 20px;">DONATE NOW</button>
              </a>

              <img src="img/wailukyawc3.jpg" width="100%" height="280px" style="position: relative;top: 18px;"><br><br>
          </div>
        </center>
      </div>
    </div>
  </div>
</div>
<!-- ======================================================================= -->

  <!-- ================================================================================== -->

  <div class="container-fluid">
  <div class="row justify-content-around" style="background-color: #E5DBEA;height: 450px;">
    <div class="col-md-12 col-xs-12 col-sm-12">
      <div class="col-md-5 col-xs-12 col-sm-12 col-md-offset-1" style="padding-top: 20px;"><br>
        <h1>WHERE WE WORK</h1><br>
        <p style="font-size: 16px;">Last year,CARE worked in 93 countries,reaching 63 million people through 950 poverty-fighting development and humanitarian aid programs.</p>
        <p>
          Explore our work in:
        </p>
        <ul>
          <li>Yangon</li>
          <li>Mandalay</li>
          <li>Bago</li>
          <li>TaungGyi</li>
        </ul>
        <br><br><br>
        <center>
          <button class="btn" id="parallelogram" style="font-weight: 500; color: #fff; background-color: #6288CA; width: 170px; height: 40px; position: relative; top:-20px;margin-right: 10px;">VIEW FULL MAP
          </button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <button class="btn" id="parallelogram" style="font-weight: 500; color: #fff; background-color: #6288CA; width: 170px; height: 40px; position: relative; top:-20px;">VIEW CRISIS MAP
          </button>
        </center>
      </div>

      <div class="col-md-5 col-xs-12 col-sm-12" style="height: 450px;padding-top: 40px;"><br>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3818.633365603478!2d96.21300891434622!3d16.844535022668605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c19373aae8dda7%3A0x66b1fddc29486ea!2sGreen+Hackers+Institute!5e0!3m2!1smy!2smm!4v1561137016652!5m2!1smy!2smm" width="106%" height="85%" frameborder="0" style="border:0; position: relative;left: -14px;" allowfullscreen></iframe><br>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>







 
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/ourimpactclick.blade.php ENDPATH**/ ?>