<header class="header site-header">
			<div class="container">
				<nav class="navbar navbar-default yamm">
				    <div class="container-fluid">
				        <div class="navbar-header">
				            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
				                <span class="sr-only">Toggle navigation</span>
				                <span class="icon-bar"></span>
				                <span class="icon-bar"></span>
				                <span class="icon-bar"></span>
				            </button>
							<a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('upload/office/'.$office->photo)); ?>" style="width:150px;height:100px;margin-top:-30px;" alt="Linda"></a>
				        </div>
				        <div id="navbar" class="navbar-collapse collapse">
				            <ul class="nav navbar-nav navbar-right">
				                <li class="<?php if($url == "home"): ?> active <?php endif; ?>"><a href="<?php echo e(url('/')); ?>">Home</a></li>
				                <li class="<?php if($url == "about"): ?> active <?php endif; ?>"><a href="<?php echo e(url('/about')); ?>">About</a></li>
				                <!-- <li><a href="service-06.html">Donating</a></li> -->
				                <li class="<?php if($url == "blog"): ?> active <?php endif; ?>"><a href="<?php echo e(url('/blog')); ?>">News</a></li>
				                <li class="<?php if($url == "contact"): ?> active <?php endif; ?>"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                                <li class="lastlink hidden-xs hidden-sm <?php if($url == "donate"): ?> <?php endif; ?>"><a class="btn btn-primary" href="<?php echo e(url('/donate')); ?>">Donate</a></li>
                            </ul>
				        </div><!--/.nav-collapse -->
				    </div><!--/.container-fluid -->
				</nav><!-- end nav -->
			</div><!-- end container -->
		</header><!-- end header --><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/site_user/navbar.blade.php ENDPATH**/ ?>