<?php $__env->startSection('title','WLK Foundation'); ?>
<?php $__env->startSection('content'); ?>
    	

		<section class="section normalhead lb" style="background: linear-gradient(45deg, #3ac5c8 1%, #0b509e 100%);">
			<div class="container">
				<div class="row">	
					<div class="col-md-10 col-md-offset-1 col-sm-12 text-center">
						<h2>About Us</h2>
					</div><!-- end col -->
				</div><!-- end row -->
			</div><!-- end container -->
		</section><!-- end section -->

		<section class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						<div class="about-widget">
							<i class="flaticon-cup"></i>
							<h3>About Us</h3>
						<p><?php echo e($office->about); ?></p>
							
	                        
						</div><!-- end about-widget -->	
					</div><!-- end col -->

					<div class="col-md-7">
						<div class="">
						<img src="<?php echo e(asset('upload/office/'.$office->photo)); ?>" alt="" class="img-responsive">
						</div>
					</div>
				</div><!-- end row -->

				<hr class="invis">

				<div class="row service-list text-center" style="margin-top:-80px;">
					

					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="service-wrapper wow fadeIn">	
							<i class="fa fa-eye"></i>
							<div class="service-details">
								<h4><a href="service-02.html" title="">Our Vision</a></h4>
								<p><?php echo e($office->vision); ?></p>
								
							</div>
						</div><!-- end service-wrapper -->
					</div><!-- end col -->

					<div class="col-md-6 col-sm-12 col-xs-12 last">
						<div class="service-wrapper wow fadeIn">	
							<i class="fa fa-bullseye"></i>
							<div class="service-details">
								<h4><a href="service-02.html" title="">Our Mission</a></h4>
								<p><?php echo e($office->mission); ?></p>
								
							</div>
						</div><!-- end service-wrapper -->
					</div><!-- end col -->
				</div><!-- end row -->

				<hr class="invis">

				<div class="row callout bgcolor" style="margin-top:-100px;">
					<div class="col-md-9">
						<p class="lead">We've hundreds of happy customers, do not you want to be a member of this family? Just join us increase your website visitors!</p>
					</div>
					<div class="col-md-3">
						<div class="button-wrap text-center">
						<a href="<?php echo e(url('/contact')); ?>" class="btn btn-transparent btn-light btn-lg">Contact us</a>
						</div>
					</div>
				</div>

				
			</div><!-- end container -->
		</section><!-- end section -->

		<section class="section ldp">
			<div class="container">
				<div class="row text-center">
					<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-2 col-sm-2 col-xs-6">
						<div class="client-box">
							<a href="#"><img src="<?php echo e(asset('/upload/blog/'.$blog_data->photo)); ?>" alt="" style="width:200px; height:140px;" class="img-responsive"></a>
						</div>
					</div><!-- end col -->
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</div><!-- end row -->
			</div><!-- end container -->
		</section><!-- end section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/about.blade.php ENDPATH**/ ?>