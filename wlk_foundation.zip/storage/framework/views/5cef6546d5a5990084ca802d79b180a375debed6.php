<?php $__env->startSection('title','WLK Foundation'); ?>
<?php $__env->startSection('content'); ?>
  <br><br>
<div class="container">
    <div class="row justify-content-around" >
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="col-md-5"><br>
                <img  src="img/wailukyawc3.jpg" alt="" style="width: 100%;height: auto;">

            </div>
            <div class="col-md-7" style="height: auto;">
                <h1>Why CARE?</h1>
                <p style="font-size: 16px;">A career at CARE is truly a one-of-a-kind experience.It's more than working for a global leader,it and opportunity to be a part of some thing that can help bring about lasting change in the world.We'll looking for experienced professional who not only align with our values but also want to make a different,developed and inspire others,drive innovative ideas and deliver results.</p><br>
                <p style="font-size: 16px;">A career at CARE is truly a one-of-a-kind experience.It's more than working for a global leader,it and opportunity to be a part of some thing that can help bring about lasting change in the world.We'll looking for experienced professional who not only align with our values but also want to make a different,developed and inspire others,drive innovative ideas and deliver results.</p><br>

                <center>
                    <h4 style="font-weight: 900;">WANT MORE INFO ON CARE? CHECK OUT THESE LINKS:</h4>
                <p>
                    <a href="" class="a">Benefit</a> |
                    <a href="" class="a">Diversity</a> |
                    <a href="" class="a">Core Values</a><br>
                    <a href="" class="a">Carrer FAQs</a> |
                    <a href="" class="a">Mission and Vision</a>
                </p><br>
                </center>
                <div class="row justify-content-end">
                  <div class="col-md-5">
                    <button class="btn" id="parallelogram" style="font-weight: 700; color: #fff; background-color: #6288CA; height: 40px; width: auto;">SEARCH FOR OPPORTUNITIES</button>
                  </div>
                  <div class="col-md-5">
                    <button class="btn" id="parallelogram" style="font-weight: 700; color: #fff; background-color: #6288CA; height: 40px;width: auto;">SEARCH FOR AN ONTERNSHIO/FELLOWSHIP</button>
                  </div>               
                
                </div>
                
            </div>
        </div>
    </div><br><br>
</div>

<!-- ---------------------------------------------------------- -->
<div class="container">
    <div class="row justify-content-around"><br><br>
      
      <div class="col-md-9 col-sm-12 col-xs-12 " style="height: auto; width: 100%">
        <div class="row">

        <div class="col-md-2 col-sm-5 col-xs-5 col-xs-offset-1 col-sm-offset-1" style="background-color: #fff;height: 330px; border-top: 10px solid orange; position: relative; left: -20px; border-bottom: 20px solid lightblue;">
            <h1 style="font-weight: 700;font-size: 21px;">FEATURED JOBS</h1><br>
            <h5 style="color: black; text-align: left;">Program Funding &<br>Reporting Coordinator</h5><br>
            <p>Establish and maintain donor relationships, prepare business strategy. <br><br>Khartoum,Sudan</p>
            
            <a href="" style="color: orange; font-weight:700;">Apply to Poition</a>
            
        </div>

        <div class="col-md-2 col-sm-5 col-xs-5  col-xs-offset-1 col-sm-offset-1" style="background-color: #fff;height: 330px; border-top: 10px solid orange;  position: relative; left: -20px; border-bottom: 20px solid lightblue;">
            <h1 style="font-weight: 700;font-size: 21px;">FEATURED JOBS</h1><br>
            <h5 style="color: black; text-align: left;">Director, Global Talent<br>Acquisition</h5><br>
            <p>Lead Talent Acquisition strategy to attract top talent globally to CARE.<br><br>Atlanta,GA</p>
            
            <a href="" style="color: orange; font-weight:700;">Apply to Poition</a>
            
        </div>

        <div class="col-md-2 col-sm-5 col-xs-5  col-xs-offset-1 col-sm-offset-1" style="background-color: #fff;height: 330px; border-top: 10px solid orange;  position: relative; left: -20px; border-bottom: 20px solid lightblue;">
            <h1 style="font-weight: 700;font-size: 21px;">FEATURED JOBS</h1><br>
            <h5 style="color: black; text-align: left;">Senior Advisor, Diversity & Inclusion</h5><br>
            <p>Bring more global diversity to CARE and ensure our culture is inclusive<br><br>Atlanta,GA</p>
            
            <a href="" style="color: orange; font-weight:700;">Apply to Poition</a>
            
        </div>

        <div class="col-md-2 col-sm-5 col-xs-5  col-xs-offset-1 col-sm-offset-1" style="background-color: #fff;height: 330px; border-top: 10px solid orange;  position: relative; left: -20px;border-bottom: 20px solid lightblue;">
            <h1 style="font-weight: 700;font-size: 21px;">FEATURED JOBS</h1><br>
            <h5 style="color: black; text-align: left;">Director, Education</h5><br>
            <p>Set CARE's strategic direction and vision for girl's empowerment through education efforts.<br><br>Atlanta,GA</p>
            
            <a href="" style="color: orange; font-weight:700;">Apply to Poition</a>
        </div>
        </div>
      </div>
    </div><br><br>
</div>

<div class="container-fluid">
    <div class="row justify-content-around" style="background-color: lightblue;height: 500px;">
      <div class="col-md-12 col-xs-12 col-sm-12">
        <div class="col-md-4 col-xs-12 col-sm-12 col-md-offset-1">
            <h1>WHERE WE WORK</h1><br>
            <p>Last year,CARE worked in 93 countries,reaching 63 million people through 950 poverty-fighting development and humanitarian aid programs.</p>
        </div>

        <div class="col-md-6 col-xs-12 col-sm-12" style="height: 450px;"><br>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3818.633365603478!2d96.21300891434622!3d16.844535022668605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c19373aae8dda7%3A0x66b1fddc29486ea!2sGreen+Hackers+Institute!5e0!3m2!1smy!2smm!4v1561137016652!5m2!1smy!2smm" width="106%" height="75%" frameborder="0" style="border:0; position: relative;left: -14px;" allowfullscreen></iframe>

            <br><br><br>

            <center><button class="btn" id="parallelogram" style="font-weight: 500; color: #fff; background-color: #6288CA; width: 170px; height: 40px; position: relative; top:-20px;">VIEW FULL MAP</button></center><br>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>







 
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/career.blade.php ENDPATH**/ ?>