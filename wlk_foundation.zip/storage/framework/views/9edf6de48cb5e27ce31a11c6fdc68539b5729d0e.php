<footer class="footer primary-footer">
            <div class="container">
                <div class="row">
					<div class="col-md-12">
						 <div class="col-md-4 col-sm-2">
                    	<div class="widget clearfix">
                    		<h4 class="widget-title">Quick Link</h4>
                    		<ul>
                    			<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    			<li><a href="<?php echo e(url('/about')); ?>">About</a></li>
                    			<li><a href="<?php echo e(url('/blog')); ?>">News</a></li>
								<li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
								<li><a href="<?php echo e(url('/donate')); ?>">Donate</a></li>
                    		</ul>
                    	</div><!-- end widget -->
                    </div><!-- end col -->

                    

                    

                    <div class="col-md-4 col-sm-2">
                    	<div class="widget clearfix">
                    		<h4 class="widget-title">Be Social</h4>
                    		<ul>
								
								<li><a href="https://www.facebook.com/wlkfoundation/" target="_blank"><img src="<?php echo e(asset('upload/facebook (1).png')); ?>" width="30px" height="30px" alt=""></a></li>
                    			<li><a href="#"><img src="<?php echo e(asset('upload/twitter.png')); ?>" width="30px" height="30px" alt=""></a></li>
                    			<li><a href="#"><img src="<?php echo e(asset('upload/google-plus.png')); ?>" width="30px" height="30px" alt=""></a></li>								
                    			
                    		</ul>
                    	</div><!-- end widget -->
					</div><!-- end col -->

					 <div class="col-md-4 col-sm-2">
                    	<div class="widget clearfix">
                    		<h4 class="widget-title">Contact</h4>
                    		<ul>
                    			<li><i class="fa fa-whatsapp">&nbsp;&nbsp;<?php echo e($office->phone); ?></i></li>
                    			<li><i class="fa fa-envelope">&nbsp;&nbsp;<?php echo e($office->email); ?></i></li>
                    			<li><i class="fa fa-fax">&nbsp;&nbsp;<?php echo e($office->address); ?></i></li>
                    		</ul>
                    	</div><!-- end widget -->
					</div><!-- end col -->
				</div>
					
                </div><!-- end row -->
           	</div><!-- end container -->
		</footer><!-- end primary-footer -->

		<footer class="footer secondary-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-md-offset-4 col-sm-6 col-xs-12">
                        <p>Copyright@ 2019 All rights reserved.Designed by GREEN HACKERS.</p>
                    </div>

                    
                </div><!-- end row -->
            </div><!-- end container -->
		</footer><!-- end second footer --><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/site_user/footer_user.blade.php ENDPATH**/ ?>