<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Admin|Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav_bar_text'); ?>
    Blog List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php echo e(session('office')); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">Office Information</h4>
                            <p class="card-category"> Here is a subtitle for this table</p>
                        </div>
                    </div>  
                </div>
                <div class="col-md-5 offset-4">
                <?php $__currentLoopData = $office; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(url('/admin/update_office')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" id="id" value="<?php echo e($offices->id); ?>">
                    <div class="form-group">
                        <label for="name" class="col-form-label">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($offices->name); ?>">
                    </div>

                    <div class="form-group">
                        <label for="address" class="col-form-label">Address:</label>
                        <!-- <textarea class="form-control" rows="4" id="address" name="address"><?php echo e($offices->address); ?></textarea> -->
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo e($offices->address); ?>">
                    </div>

                     <div class="form-group">
                        <label for="phone" class="col-form-label">Phone No:</label>
                        <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo e($offices->phone); ?>">
                    </div><br>
                    <input type="submit" name="submit" class="btn btn-primary" value="Edit Office Information">
                </form>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script>
        function editBlog(id){
           $('#blog').modal('show');
           var id = document.getElementById('id'+id).innerHTML;
           var title = document.getElementById('title'+id).innerHTML;
           var detail = document.getElementById('detail'+id).innerHTML;
           var img = document.getElementById('img'+id).innerHTML;
           $('#blog_id').val(id);
           $('#title').val(title);
           $('#detail').val(detail);
           $('#photo').val(img);
           
        }
        function deleteBlog(deletelay){

           var trueName =  confirm("Are You Want To Delete?");
           if(trueName){
               window.open(deletelay,'_self');
           }else {
              alert("You not deleted");
           }
        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site_admin.site_admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\power_phoenix\resources\views/site_admin/office.blade.php ENDPATH**/ ?>