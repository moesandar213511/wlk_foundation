<div class="topbar">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 hidden-xs">
                        <nav class="topbar-menu">
                            <ul class="list-inline">
                            	<li>Follow us: </li>
                                <li><a href="https://www.facebook.com/wlkfoundation/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            </ul><!-- end list -->
                        </nav><!-- end menu -->
                    </div><!-- end col -->

                    <div class="col-md-6 col-sm-6">
                        <nav class="topbar-menu">
                            <ul class="list-inline text-right navbar-right">
                                <li class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#"><img src="{{url('images/1.png')}}" alt=""></a>
                                <a href="#"><img src="{{url('images/2.png')}}" alt=""></a>
                                    <!-- <ul class="dropdown-menu">
                                        <li><a href="#"><img src="images/2.png" alt=""> Turkish</a></li>
                                         <li><a href="#"><img src="images/si.png" alt=""> Spanish</a></li>
                                        <li><a href="#"><img src="images/it.png" alt=""> Italian</a></li>
                                        <li><a href="#"><img src="images/ae.png" alt=""> Arabic</a></li>
                                        <li><a href="#"><img src="images/de.png" alt=""> German</a></li>
                                    </ul> -->
                                </li>
                                {{-- <li class="hidden-xs"><i class="fa fa-clock-o"></i> 08:00 - 17:00</li>
                                <li><i class="fa fa-phone"></i> +90 987 665 55 44</li> --}}
                            </ul><!-- end list -->
                        </nav><!-- end menu -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end topbar -->