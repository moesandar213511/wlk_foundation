<?php $__env->startSection('title','Power Phoenix'); ?>
<?php $__env->startSection('content'); ?>
<!-- banner -->
<div class="banner_w3lspvt">
    <div class="csslider infinity" id="slider1">
        <input type="radio" name="slides" checked="checked" id="slides_1"/>
        <input type="radio" name="slides" id="slides_2"/>
        <input type="radio" name="slides" id="slides_3"/>
        <input type="radio" name="slides" id="slides_4"/>

      <!--   <ul class="banner_slide_bg">
            <li>
                <div class="slider-info bg1">
                    <div class="bs-slider-overlay1">
                        <div class="banner-text">
                            <div class="container">
                                <h5 class="tag mb-3 text-uppercase">We are professional <span class="ml-2"><span></h5>
                                <h1 class="movetxt agile-title text-capitalize">Consult Your</h1>
                                <h4 class="movetxt mb-3 agile-title text-capitalize">Business With Us</h4>
                                <p>Vivamus eget est in odio tempor interdum. Mauris maximus fermentum arcu, ac finibus ante. Sed mattis risus at ipsum elementum,
                                ut auctor turpis cursus. Sed sed odio pharetra, aliquet velit cursus, vehicula enim. Mauris porta aliquet magna, eget laoreet ligula.</p>                   
                                <a class="btn mt-4 text-capitalize" href="#welcome"> Know More </a>
                                <a class="btn btn1 mt-4 text-capitalize scroll" href="#contact" > Get Started </a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="slider-info bg2">
                    <div class="bs-slider-overlay1">
                        <div class="banner-text">
                            <div class="container">
                                <h5 class="tag mb-3 text-uppercase">We are unique <span class="ml-2"><span></h5>
                                <h4 class="movetxt agile-title text-capitalize">Creative Design </h4>
                                <h4 class="movetxt mb-3 agile-title text-capitalize">Manage Business </h4>  
                                <p>Vivamus eget est in odio tempor interdum. Mauris maximus fermentum arcu, ac finibus ante. Sed mattis risus at ipsum elementum,
                                ut auctor turpis cursus. Sed sed odio pharetra, aliquet velit cursus, vehicula enim. Mauris porta aliquet magna, eget laoreet ligula.</p>                   
                                <a class="btn mt-4 text-capitalize" href="#welcome"> Know More </a>
                                <a class="btn btn1 mt-4 text-capitalize scroll" href="#contact" > Get Started </a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="slider-info bg3">
                    <div class="bs-slider-overlay1">
                        <div class="banner-text">
                            <div class="container">
                                <h5 class="tag mb-3 text-uppercase">We are creative <span class="ml-2"><span></h5>
                                <h4 class="movetxt agile-title text-capitalize">High Quality </h4>
                                <h4 class="movetxt mb-3 agile-title text-capitalize">Creative thinking </h4>    
                                <p>Vivamus eget est in odio tempor interdum. Mauris maximus fermentum arcu, ac finibus ante. Sed mattis risus at ipsum elementum,
                                ut auctor turpis cursus. Sed sed odio pharetra, aliquet velit cursus, vehicula enim. Mauris porta aliquet magna, eget laoreet ligula.</p>                   
                                <a class="btn mt-4 text-capitalize" href="#welcome"> Know More </a>
                                <a class="btn btn1 mt-4 text-capitalize scroll" href="#contact" > Get Started </a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="slider-info bg4">
                    <div class="bs-slider-overlay1">
                        <div class="banner-text">
                            <div class="container">
                                <h5 class="tag mb-3 text-uppercase">We are awesome <span class="ml-2"><span></h5>
                                <h4 class="movetxt agile-title text-capitalize">Tons of Projects </h4>
                                <h4 class="movetxt mb-3 agile-title text-capitalize">With Consultancy </h4> 
                                <p>Vivamus eget est in odio tempor interdum. Mauris maximus fermentum arcu, ac finibus ante. Sed mattis risus at ipsum elementum,
                                ut auctor turpis cursus. Sed sed odio pharetra, aliquet velit cursus, vehicula enim. Mauris porta aliquet magna, eget laoreet ligula.</p>                   
                                <a class="btn mt-4 text-capitalize" href="#welcome"> Know More </a>
                                <a class="btn btn1 mt-4 text-capitalize scroll" href="#contact" > Get Started </a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        </ul> -->
        <div class="navigation"> 
            <div>
              <label for="slides_1"></label>
              <label for="slides_2"></label>
              <label for="slides_3"></label>
              <label for="slides_4"></label>
            </div>
        </div>
    </div>
</div>
<!-- //banner -->
<ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item active">Contact</li>
</ol>

<!-- Contact -->
<section class="contact py-5" id="contact">
    <div class="container py-sm-3">
        <h1 class="heading text-capitalize mb-lg-5 mb-4">Contact Us</h1>
        <form action="#" method="post">
            <div class="row main-agile-sectns">
                <div class="col-md-6 agileits-btm-spc form-text1">
                    <input type="text" name="Name" placeholder="Enter Your Name" required="">
                </div>
                <div class="col-md-6 agileits-btm-spc form-text2">
                    <input type="text" name="Phone no" placeholder="Enter Phone Number" required="">
                </div>
            </div>
            <div class="row main-agile-sectns">
                <div class="col-md-6 agileits-btm-spc form-text1">
                    <input type="text" name="subject" placeholder="Enter Subject">
                </div>
                
                <div class="col-md-6 agileits-btm-spc form-text1">
                    <input type="email" name="email" placeholder="Enter Your Email" required="">
                </div>
            </div>
            <div class="main-agile-sectns ">
                <div class="agileits-btm-spc form-text2 p-0">
                    <textarea placeholder="Enter Your Message Here"></textarea>
                </div>
            </div>
            <button type="submit" class="btn">Submit</button>
        </form>
    </div>
</section>
<!-- //Contact -->

  <section class="map">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d432907.5172146211!2d115.68134600573292!3d-32.039755859702055!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2a32966cdb47733d%3A0x304f0b535df55d0!2sPerth+WA%2C+Australia!5e0!3m2!1sen!2sin!4v1550906152641" allowfullscreen></iframe>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\power_phoenixajax\resources\views/user/contact.blade.php ENDPATH**/ ?>