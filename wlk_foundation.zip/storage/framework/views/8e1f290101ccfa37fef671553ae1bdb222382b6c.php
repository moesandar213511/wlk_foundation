<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Wai Lu Kyaw Foundation</title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Bootstrap Lesson</title>

    <!-- Bootstrap -->

   <link href="<?php echo e(asset('user/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('user/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('user/css/style2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/css/style3.css')); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
   
  <!--   <link rel="stylesheet" href="assets/css/font-awesome.min.css"> -->
     <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <body style="background-color: lightblue;">
      <div class="container-fluid" >
        <div class="row">
            <nav class="nav navbar-default" style="background-color: #4889B6; height: 80px;">

                <!-- <button class="navbar-toggle" data-toggle="collapse" data-target="#one">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button> -->
                <div class="navbar-collapse collapse navbar-center" id="one">
                    <div class="col-md-6" >
                      <ul class="nav navbar-nav " style="position: relative; right: -100px; top: 5px;">
                          <a href="<?php echo e(url('/')); ?>" class="text-white" style="">
                            <h3 id="logo" style="color: white;">WLK fdn-Logo</h3>
                          </a>
                      </ul>
                    </div>


                  <div class="col-md-6" id="donate">
                    <ul class="nav navbar-nav pull-right" style="position: relative; left: -100px;">
                        <li class="custom1"><a href="#" style="font-size: 20px; font-weight: 800; color: #fff; position: relative; top: 15px;">FIGHT WITH CARE &reg;</a></li>
                        
                        
                    </ul>
                  </div>
              </div>  
            </nav>
        </div>    
      </div><br>

      <div class="container">
          <div class="row" >
              
                  <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
                    <h1 style="font-size: 40px; font-weight: 1000;">MAKE A DIFFERENCE:</h1>
                      <br>
                      <p style="font-size: 14px; font-weight: 400;">Sign up now and find you can make and impact on the lives of those struggling with poverty,<br>disease and disaster around the world.</p>
                    <br><br>

                    <div class="row justify-content-around">
                      <div class="col-md-5">
                        <input type="text" name="first" class="form-control" placeholder=" First Name" style="border: 1px solid #7AABD6; width: 100%; height: 40px;">
                        <br><br>
                      </div>
                      <div class="col-md-5">
                        <input type="text" name="last" class="form-control" placeholder=" Last Name"  style="border: 1px solid #7AABD6; width: 100%; height: 40px;">
                    <br><br>
                      </div>
                    </div>
                    
                <div class="row justify-content-start">
                  <div class="col-md-10">
                    <input type="text" name="email" class="form-control" placeholder=" E-Mail"  style="border: 1px solid #7AABD6; width: 100%; height: 40px;">
                    <br><br>
                  </div>
                </div>
                 <div class="row justify-content-around">
                      <div class="col-md-5">
                          <input type="text" name="phno" class="form-control" placeholder=" Phone Number" style="border: 1px solid #7AABD6; width: 100%; height: 40px;">
                          <br><br>
                      </div>
                  
                      <div class="col-md-5">
                         <button id="parallelogram" class="btn" style=" width: 100%;height: 40px; font-weight: 700;font-size: 20px; color: white; background-color: #B51D7E;">SUBMIT</button><br><br>
                      </div>
                  </div>
                </div>
                  <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                    <img src="img/wailukyaw1.jpg" alt="" style="width: 100%; height: 550px;">
                  </div>
              
          </div><br><br>
      </div>
      <div class="container-fluid" style="background-color: #000; height: 400px;">

          <div class="row">
                
                  <div class="col-md-10 col-xs-12 col-md-offset-1">
                    <div class="row">
                        <div class="col-md-6 col-xs-12">
                          <div class="row" style="height: 250px;"><br><br><br><br>
                            <center><img src="img/myr.png" alt="" style="width: 180px; height: 100px; ">
                            </center>
                          </div>
                          
                          <div class="row">
                          <div class="column">
                          </div>
                     </div>
                    

                        </div>
                        <div class="col-md-6 col-xs-12">
                          <div class="row">
                          <p style="font-size: 20px; font-weight: 600; color: #fff; padding-top: 50px;">To donate,please call us at 0934879543 CARE within the U.S(24 hours) or +9594658734676 (M-F,8:30 a.m - 6:00 p.m ET).</p><br>
                          <p style="font-size: 20px; font-weight: 600; color: #fff;">CARE is a nonprofit 501 (c)(3) public charity (tax ID# 13-1685039).</p><br>
                          </div>                        
                    </div>
                    
                  </div>
                <div class="container-fluid">
                  <div class="row">
                      <div style="background-color: black; width:100%, height:60px; ">
                        <center><img src="WLK_Foundation/wlk" alt="" style="width: 200px; height: 100px;"><br>
                        <p style="font-size: 15px; font-weight: 600; color: #fff; text-shadow: 0px 0px 30px #fff;">&copy;2019 WLK_Foundation All Right Reserved</p><br>
                        </center>
                      </div>
                  </div>
                </div>
      
  <script rel="stylesheet" src="<?php echo e(asset('user/js/jquery.min.js')); ?>"></script>
  <script rel="stylesheet" src="<?php echo e(asset('user/js/bootstrap.min.js')); ?>"></script>
</body>
</html><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/joinus.blade.php ENDPATH**/ ?>