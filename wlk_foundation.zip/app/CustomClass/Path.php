<?php

namespace App\CustomClass;

class Path{
	public static $path="http://localhost/wlk_foundation/public/";
}