<?php $__env->startSection('title','Power Phoenix'); ?>
<?php $__env->startSection('content'); ?>
<!-- banner -->
<div class="banner_w3lspvt" id="home">
	<div class="csslider infinity" id="slider1">
		<input type="radio" name="slides" checked="checked" id="slides_1"/>
		<input type="radio" name="slides" id="slides_2"/>
		<input type="radio" name="slides" id="slides_3"/>
		<input type="radio" name="slides" id="slides_4"/>

	
		<div class="navigation"> 
			<div>
			  <label for="slides_1"></label>
			  <label for="slides_2"></label>
			  <label for="slides_3"></label>
			  <label for="slides_4"></label>
			</div>
		</div>
	</div>
</div>
<!-- //banner -->
<ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="index.html">Home</a>
        </li>
        <li class="breadcrumb-item active">Blog</li>
</ol>
<section class="ab-info-main py-md-5 py-4">
        <div class="container py-md-5 py-4">
            <h3 class="tittle text-center mb-lg-5 mb-3">Blog</h3>
            <?php if(count($blog) >0): ?>
                <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if(($index+1)%2 == 0): ?>
                    <div class="row mt-lg-5 mt-4">
                        <div class="col-md-6 events-info">
                            <h3><span class="sub-tittle">0<?php echo e($index+1); ?></span></h3>
                            <h4 class="my-3"><a href="<?php echo e(url('/blogDetail/'.$data->id)); ?>" class="text-dark"><?php echo e($data['title']); ?></a></h4>
                             <ul class="events-icons new-inf mt-md-4 mt-3 d-flex">
                                <li><a href="#"><span class="fa fa-calendar"></span></a> 
                                    <?php echo e($data['created_at']->format('M d-Y')); ?></li>
                            </ul>
                            <p style="margin-top: 20px;"><?php echo e(str_limit($data['detail'],200)); ?></p>
                        </div>
                        <div class="col-md-6 events-img">
                            <a href="single.html"><img src="<?php echo e(asset('upload/blog/'.$data['photo'])); ?>" class="img-fluid" width="500px" height="400px" alt="user-image" /></a>
                        </div>
                    </div>
                    <?php else: ?>
                     <div class="row mt-lg-5 mt-4">
                        <div class="col-md-6 events-img">
                            <a href="single.html"><img src="<?php echo e(asset('upload/blog/'.$data['photo'])); ?>" class="img-fluid" width="500px" height="400px" alt="user-image" /></a>
                        </div>
                        <div class="col-md-6 events-info">
                            <h3><span class="sub-tittle">0<?php echo e($index+1); ?></span></h3>
                            <h4 class="my-3"><a href="<?php echo e(url('/blogDetail/'.$data->id)); ?>" class="text-dark"><?php echo e($data['title']); ?></a></h4>
                             <ul class="events-icons new-inf mt-md-4 mt-3 d-flex">
                                <li><a href="#"><span class="fa fa-calendar"></span></a> <?php echo e($data['created_at']->format('M d-Y')); ?></li>
                            </ul>
                            <p style="margin-top: 20px;"><?php echo e(str_limit($data['detail'],200)); ?></p>
                        </div>
                    </div>
                   <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <h2>No Post</h2>
            <?php endif; ?>

        </div>
</section>

<div class="container">
        <div class="row">
            <div class="col-md-12" style="margin-bottom: 40px;">
                <div>
                    <!-- <?php echo e($blog->links()); ?> -->
                    <?php echo e($blog->render()); ?>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\power_phoenix\resources\views/user/blog.blade.php ENDPATH**/ ?>