<!DOCTYPE html>
<html lang="en">
<head>
<title><?php echo $__env->yieldContent('title'); ?></title>
	
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Consult-Biz Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->
	
	<!-- css files -->
	<link rel="stylesheet" href="<?php echo e(asset('client/css/bootstrap.css')); ?>"> <!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('client/css/style.css')); ?>" type="text/css" media="all" /> <!-- Style-CSS --> 
	<link rel="stylesheet" href="<?php echo e(asset('client/css/font-awesome.min.css')); ?>" type="text/css" media="all" /> <!-- Style-CSS --> 
	<!-- //css files -->
	
	<!--web font-->
	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
	<!--//web font-->

</head>
<body>

<!-- header -->
<?php echo $__env->make('user.site_user.header_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- //header -->
<?php echo $__env->yieldContent('content'); ?>

<!-- footer -->
<?php echo $__env->make('user.site_user.footer_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- //footer -->

</body>
</html><?php /**PATH D:\xampp\htdocs\power_phoenix\resources\views/user/site_user/master_user.blade.php ENDPATH**/ ?>