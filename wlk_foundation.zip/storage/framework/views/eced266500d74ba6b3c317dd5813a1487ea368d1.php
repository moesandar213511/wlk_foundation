<footer class="py-5">
	<div class="container">
		<div class="row footer_grids">
			<div class="col-lg-4 footer_left">
				<h2><a class="footer-logo" href="index.html">
				Power Phoenix</a></h2>
				<p>Nulla felis tortor, rutrum eget feugiat non, blandit nec tellus. Nam pharetra ipsum ligula volutpat, a finibus.
				Fusce males uada sollicitudin venenatis. </p>
			</div>
			<div class="col-lg-4 col-md-6 mt-lg-0 mt-sm-5 mt-4 footer_middle">
				<h3 class="mb-sm-4 mb-3">Facebook Feed</h3>
				<ul>
					<li class="mb-2">Ut aut reiciendis voluptatibus Nam pharet <a href="#">http://example.com</a> alias.
						<span>- <span class="fa mr-1 fa-facebook" aria-hidden="true"></span> 02 days ago</span></li>
					<li>Itaque earum rerum hic tenetur a sapiente <a href="#">http://example.com</a>
					<span>- <span class="fa mr-1 fa-facebook" aria-hidden="true"></span> 03 days ago</span></li>
				</ul>
			</div>
			<div class="col-lg-4 col-md-6 mt-lg-0 mt-sm-5 mt-4 footer_right">
				<h3 class="mb-sm-4 mb-3">Contact Info</h3>
				<p> <span class="fa mr-1 fa-map-marker"></span> No.(88/90) 51 street(Middle Block), Pazundaung Township Yangon 11171 </p>
				<p> <span class="fa mr-1 fa-envelope"></span> <a href="powerphoenixmyanmar@.com">powerphoenixmyanmar@.com</a> </p>
				<p> <span class="fa mr-1 fa-phone"></span> 09 897 711887 </p>
				<p> <span class="fa mr-1 fa-clock-o"></span> Everyday 9:00–14:00</p>
			</div>
		</div>
		<!-- To Top -->
		<div class="top-icon mt-2 text-center">
			<a href="#home" class="move-top text-center"><span class="fa fa-angle-up  mb-3" aria-hidden="true"></span></a>
		</div>
		<!-- //To Top -->
	</div>
</footer>
		<div class="copyright text-center py-3">
			<p>© 2019 Power Phoenix. All Rights Reserved | Design by <a href="https://www.facebook.com/powerphoenixmyanmar"> Power Phoenix Myanmar</a> </p>
		</div><?php /**PATH D:\xampp\htdocs\power_phoenix\resources\views/user/site_user/footer_user.blade.php ENDPATH**/ ?>