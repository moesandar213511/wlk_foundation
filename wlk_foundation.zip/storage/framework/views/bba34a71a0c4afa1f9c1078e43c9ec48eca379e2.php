<?php $__env->startSection('title','WLK Foundation'); ?>
<?php $__env->startSection('content'); ?>
  <div class="container-fluid" style="background-color: lightblue;">
  <br><br>
  <div class="row justify-content-around">
   <div class="col-md-12 col-xs-12 col-sm-12 col-xs-12 " style=" width: 100%;height: 100%;">

          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
            <div class="" style="background-color: #fff;  border-top: 10px solid orange; position: relative;height: auto;width: 90%; border-bottom: 30px solid lightblue;margin-left: 5%;">
                <h1 style="font-weight: 700;font-size: 21px; padding-left: 5%;">PRESS RELEASES</h1>
                
                  <p style="padding-left: 5%;">Browse through our recent press releases.</p>
                
                <br>
                <button id="parallelogram" class="btn pull-right" style="background-color: orange; color: white;">LEARN MORE</button><br><br>
               <img class=" col-lg-3 col-md-3 col-sm-3 col-xs-3 " src="img/coffee/coffee (5).jpg" style="padding:10px ; border-radius: 15px">
                <img class=" col-lg-3 col-md-3 col-sm-3 col-xs-3 " src="img/coffee/coffee (2).jpg" style="padding:10px ; border-radius: 15px">
                <img class=" col-lg-3 col-md-3 col-sm-3 col-xs-3 " src="img/coffee/coffee (3).jpg" style="padding:10px ; border-radius: 15px">
                <img class=" col-lg-3 col-md-3 col-sm-3 col-xs-3 " src="img/coffee/coffee (4).jpg" style="padding:10px ; border-radius: 15px">
                <br><br><br><br><br>
                
            </div>
          </div>
           


          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            <div class="" style="background-color: #fff;  border-top: 10px solid orange; position: relative;height: auto;width: 90%;border-bottom: 30px solid lightblue; margin-left: 5%;">
                <h1 style="font-weight: 700;font-size: 21px;padding-left: 5%;">PRESS RELEASES</h1>
                
                  <p style="padding-left: 5%;">Browse through our recent press releases.</p>
                <br>
                <button id="parallelogram" class="btn pull-right" style="background-color: orange; color: white;">LEARN MORE</button><br><br>
                <img class=" col-lg-3 col-md-3 col-sm-3 col-xs-3 " src="img/coffee/coffee (6).jpg" style="padding:10px ; border-radius: 15px">
                <img class=" col-lg-3 col-md-3 col-sm-3 col-xs-3 " src="img/coffee/coffee (7).jpg" style="padding:10px ; border-radius: 15px">
                <img class=" col-lg-3 col-md-3 col-sm-3 col-xs-3 " src="img/coffee/coffee (9).jpg" style="padding:10px ; border-radius: 15px">
                <img class=" col-lg-3 col-md-3 col-sm-3 col-xs-3 " src="img/coffee/coffee (8).jpg" style="padding:10px ; border-radius: 15px">
                <br><br><br><br><br>
                
            </div>
          </div>
        </div>
     </div>

      

      <div class="row justify-content-center" style="background-color: #629AC0;">
        <div class="col-md-11 col-sm-12 col-xs-12 col-md-offset-1 "><br>

           <!--  <div class="col-lg-12 " style=" background-color: #fff;height: auto; width: 90%; border-top: 10px solid orange;"> -->
            <div class="col-lg-11 col-md-12 col-sm-12 col-xs-12" style="background-color: #fff; height: auto; width: 78%; border-top: 10px solid orange; margin-right: 110px; position: relative; right: -70px;margin-bottom: 50px solid  #629AC0; border-bottom: 20px solid #629AC0;">

              <center>
                <h1 style="font-weight: 700;font-size: 25px; padding-left: 5%;">IN THE NEWS</h1>
              </center>

                
                <img src="img/poor3.jpg" width="30%" height="120px"><br>
                <label>6/5/19</label><br>
                <p style=""><b>Thomson Reuters Foundation: Cameroon tops list of the world's most neglected displacement crises</b></p>
                <p >The Thomson Reuters Foundation quoted Helen Thompson,CARER International UK head of humanitarian programs , on the struggle to meet increasing needs with limited funding.</p><br>
                <hr>
                <img src="img/poor4.jpg" width="30%" height="120px" ><br>
                <label>6/5/19</label>
                <p><b>Devex:Coalition aims to streamline awareness efforts,attract new donors</b></p>
                <p>Devex featured the renewed commitment of CARER with seven NGOs for the Global Emergency Response Coalition,an alliance to help children and families affected by rapid-onset...</p><br>
                
                <button id="parallelogram" class="btn pull-right" style="background-color: orange; color: white;">SEE MORE</button><br><br><br>
            </div>
        </div>
      </div>
    <!-- </div> -->
</div>

<!-- background-color: #fff; height: auto; width: 78%; border-top: 10px solid orange; margin-right: 110px; position: relative; right: -70px; -->
<div class="container-fluid" >
    <div class="row" style="background-color: lightblue;"><br><br>
       <div class="col-md-11 col-md-offset-1" style=" ">

            <div class="col-lg-11 col-md-12 col-sm-12 col-xs-12" style="border-radius: 10px;background-color: #fff; height: auto; width: 78%; border-top: 10px solid orange; margin-right: 110px; position: relative; right: -70px; border-bottom: 20px solid lightblue;">
             
              <h1 style="font-weight: 700;font-size: 21px;padding-left: 20px; ">MEET OUR MEDIA TEAM</h1>
                
                <p>For media requests only.For other inquires,please visit visit <a href="" style="color: orange;">www.care.org/contact.</a></p>

                <button id="parallelogram" class="btn pull-right" style="background-color: orange; color: white;">GET CONTACT INFO</button><br><br>

                <hr>
                  
                      <img class="col-lg-3 col-md-4 col-sm-4 col-xs-6 " src="img/coffee/coffee (1).jpg" style="padding:10px ; border-radius: 15px">
                      <img class="col-lg-3 col-md-4 col-sm-4 col-xs-6" src="img/coffee/coffee (1).jpg" style="padding:10px ; border-radius: 15px">
                      <img class="col-lg-3 col-md-4 col-sm-4 col-xs-6" src="img/coffee/coffee (1).jpg" style="padding:10px ; border-radius: 15px">
                      <img class="col-lg-3 col-md-4 col-sm-4 col-xs-6" src="img/coffee/coffee (1).jpg" style="padding:10px ; border-radius: 15px">
                      <img class="col-lg-3 col-md-4 col-sm-4 col-xs-6" src="img/coffee/coffee (1).jpg" style="padding:10px ; border-radius: 15px">
                      <img class="col-lg-3 col-md-4 col-sm-4 col-xs-6" src="img/coffee/coffee (1).jpg" style="padding:10px ; border-radius: 15px">
            </div>
        </div>
    </div><br>
</div>


<!-- ============================================================================= -->

<!-- <div class="container-fluid">
  <div class="row" style="">
    <div class="column">
        <img src="picture/map.jpg" alt="" style="width: 100%; height: auto; position: relative;">
    </div>
</div>
</div> -->


<!-- ---------------------------------=====---------------------------------- -->
   
  <!-- ======================================================================= -->
  <div class="container-fluid"><br>
    <div class="row justify-content-around" style="background-color: #629AC0;height: 500px;">
      <div class="col-md-12 col-xs-12 col-sm-12"><br>
        <div class="col-md-4 col-xs-12 col-sm-12 col-md-offset-1"><br>
            <h1>WHERE WE WORK</h1><br>
            <p>Last year,CARE worked in 93 countries,reaching 63 million people through 950 poverty-fighting development and humanitarian aid programs.</p>
        </div>

        <div class="col-md-6 col-xs-12 col-sm-12" style="height: 450px;"><br><br>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3818.633365603478!2d96.21300891434622!3d16.844535022668605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c19373aae8dda7%3A0x66b1fddc29486ea!2sGreen+Hackers+Institute!5e0!3m2!1smy!2smm!4v1561137016652!5m2!1smy!2smm" width="106%" height="75%" frameborder="0" style="border:0; position: relative;left: -14px;" allowfullscreen></iframe>

            <br><br><br>

            <center><button class="btn" id="parallelogram" style="font-weight: 500; color: #fff; background-color: #6288CA; width: 170px; height: 40px; position: relative; top:-20px;">VIEW FULL MAP</button></center><br>
        </div><br><br>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>







 
<?php echo $__env->make('user.site_user.master_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wlk_foundation\resources\views/user/newsroom.blade.php ENDPATH**/ ?>